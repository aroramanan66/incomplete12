from flask import Flask
import os
from pprint import pprint
from google.cloud import storage
import google.cloud.storage
import json
import os
import sys
app=Flask(__name__)
@app.route('/')
def vit():
    os.environ['GOOGLE_APPLICATION_CREDENTIALS'] = 'resourcebusy-testing-9c296e198f25.json'
    storage_client = storage.Client()
    bucket_name = 'resoucebusymanan_127'
    bucket = storage_client.bucket(bucket_name)
    bucket.storage_class = 'STANDARD' # Archive | Nearline | Standard
    bucket.location = 'US' # Taiwan
    bucket = storage_client.create_bucket(bucket)
    PATH=os.path.join(os.getcwd(),'resourcebusy-testing-9c296e198f25.json')
    os.environ['GOOGLE_APPLICATION_CREDENTIALS']=PATH
    storage_client=storage.Client(PATH)
    filename='index.html'
    UPLOADFILE=os.path.join(os.getcwd(),filename)
    bucket=storage_client.get_bucket('resoucebusymanan_127')
    blob=bucket.blob(filename)
    blob.upload_from_filename(UPLOADFILE)
    return "Task Compeleted"

if __name__=='__main__':
    app.run(debug=True,host="0.0.0.0",port=(os.environ.get("PORT" ,8080)))
